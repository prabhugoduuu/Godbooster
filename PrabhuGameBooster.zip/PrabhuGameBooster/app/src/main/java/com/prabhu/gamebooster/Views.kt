package com.prabhu.gamebooster

import android.content.Context
import android.graphics.*
import android.view.View

class GaugeView(c: Context) : View(c) {
    var label = ""
    private var value = -1
    private var txt = "--"
    private var col = Util.CYAN
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(v: Int, t: String, color: Int) { value = v; txt = t; col = color; invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        val s = MeasureSpec.getSize(w); setMeasuredDimension(s, (s * 0.92f).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val s = w * 0.09f
        val rect = RectF(s, s, w - s, w - s)
        p.style = Paint.Style.STROKE; p.strokeWidth = s; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#26FFFFFF"); cv.drawArc(rect, 135f, 270f, false, p)
        if (value >= 0) { p.color = col; cv.drawArc(rect, 135f, 270f * value.coerceIn(2, 100) / 100f, false, p) }
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = w * 0.23f
        cv.drawText(txt, w / 2, w * 0.54f, p)
        p.color = Color.parseColor("#8FA3BF"); p.typeface = Typeface.DEFAULT; p.textSize = w * 0.14f
        cv.drawText(label, w / 2, w * 0.82f, p)
    }
}

class BubbleView(c: Context) : View(c) {
    var ram = 0
    var temp = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun col() = if (temp >= 42) Util.RED else if (temp >= 38) Util.ORANGE else Util.CYAN
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val r = w / 2; val m = w * 0.08f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#F00B0F1A"); cv.drawCircle(r, r, r - 2, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.08f; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#33FFFFFF"); cv.drawCircle(r, r, r - m, p)
        p.color = col()
        cv.drawArc(RectF(m, m, w - m, w - m), -90f, 360f * ram.coerceIn(3, 100) / 100f, false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.color = Color.WHITE
        p.textSize = w * 0.32f; cv.drawText("⚡", r, r + w * 0.02f, p)
        p.textSize = w * 0.18f; p.color = col(); p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText("${temp.toInt()}°", r, w * 0.80f, p)
    }
}
