package com.prabhu.gamebooster

import android.app.*
import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs

class BubbleView(c: Context) : View(c) {
    var ram = 0
    var temp = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun col() = if (temp >= 42) Util.RED else if (temp >= 38) Util.ORANGE else Util.CYAN
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val r = w / 2; val m = w * 0.08f
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#F00B0F1A"); cv.drawCircle(r, r, r - 2, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.08f; p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#33FFFFFF"); cv.drawCircle(r, r, r - m, p)
        p.color = col()
        cv.drawArc(RectF(m, m, w - m, w - m), -90f, 360f * ram.coerceIn(3, 100) / 100f, false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.color = Color.WHITE
        p.textSize = w * 0.32f; cv.drawText("⚡", r, r + w * 0.02f, p)
        p.textSize = w * 0.18f; p.color = col(); p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText("${temp.toInt()}°", r, w * 0.80f, p)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: BubbleView? = null
    private var panel: LinearLayout? = null
    private var content: FrameLayout? = null
    private var web: WebView? = null
    private var bannerView: View? = null
    private val tabBtns = ArrayList<TextView>()
    private var vRam: TextView? = null
    private var vTemp: TextView? = null
    private var vPing: TextView? = null
    private var vBat: TextView? = null
    private var vStatus: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private var alive = true
    @Volatile private var ping = -1L
    private val sens = IntArray(6)
    private val sensNames = listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper", "AWM")
    private val presets = linkedMapOf(
        "Normal" to intArrayOf(75, 70, 65, 60, 50, 45),
        "High" to intArrayOf(88, 84, 80, 75, 65, 60),
        "Pro" to intArrayOf(95, 92, 88, 84, 75, 70),
        "Max" to intArrayOf(100, 100, 98, 95, 88, 85))

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = Util.dp(this, v)
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun mlp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
    private fun wlp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("pgb", "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pgb") else Notification.Builder(this))
            .setContentTitle("Prabhu Game Booster running").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        val d = presets["High"]!!
        for (k in 0..5) sens[k] = sp.getInt("s$k", d[k])
        addBubble(); tick()
    }

    // ---------- bubble ----------
    private fun addBubble() {
        val b = BubbleView(this)
        val lp = WindowManager.LayoutParams(dp(58), dp(58), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 20; lp.y = 300
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var longDone = false
        val lpr = Runnable { if (!moved) { longDone = true; doBoost(false) } }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; longDone = false; h.postDelayed(lpr, 600); true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) { moved = true; h.removeCallbacks(lpr) }
                    lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(b, lp); true
                }
                MotionEvent.ACTION_UP -> { h.removeCallbacks(lpr); if (!moved && !longDone) togglePanel(); true }
                else -> false
            }
        }
        wm.addView(b, lp); bubble = b
    }

    // ---------- banner ----------
    private fun banner(title: String, sub: String) {
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(22), dp(14), dp(22), dp(14))
            background = Util.round(this@OverlayService, Color.parseColor("#F20B0F1A"), 18, Util.GREEN)
        }
        ll.addView(TextView(this).apply { text = title; setTextColor(Util.GREEN); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        ll.addView(TextView(this).apply { text = sub; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(60)
        ll.alpha = 0f; ll.scaleX = 0.7f; ll.scaleY = 0.7f
        wm.addView(ll, lp); bannerView = ll
        ll.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start()
        h.postDelayed({
            if (bannerView === ll) {
                ll.animate().alpha(0f).setDuration(300).withEndAction { try { wm.removeView(ll) } catch (e: Exception) {} }.start()
                bannerView = null
            }
        }, 2800)
    }

    private fun doBoost(play: Boolean) {
        banner("⚡ BOOSTING...", "Background apps close avthunnayi")
        Util.boost(this) { freed, avail ->
            val dnd = Util.dnd(this, true)
            val t = Util.temp(this)
            banner("✅ GAME BOOSTED!",
                (if (freed > 0) "🧹 $freed MB freed" else "🧹 RAM already clean") + "   💾 $avail MB free\n🌡 %.0f°C".format(t) +
                    (if (dnd) "   🔕 DND ON" else ""))
            if (play) { closePanel(); if (!Util.launchGame(this)) banner("❌ Free Fire dorakaledu", "Game install undo check chey") }
            refreshStats()
        }
    }

    // ---------- panel ----------
    private fun small(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(12), dp(4), dp(12), dp(4)); setOnClickListener { f() } }

    private fun label(t: String, size: Float = 12f, color: Int = Color.parseColor("#8FA3BF")) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setPadding(dp(4), dp(6), dp(4), dp(2)) }

    private fun scroll(v: View) = ScrollView(this).apply { addView(v) }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val c = this
        val p = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Util.round(c, Color.parseColor("#F40B0F1A"), 22, Util.CYAN)
        }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(c).apply {
            text = "⚡ PRABHU GAME BOOSTER"; setTextColor(Util.CYAN); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        head.addView(small("✕") { closePanel() }); head.addView(small("⏻") { stopSelf() })
        val tabs = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        tabBtns.clear()
        listOf("📊 DASH", "🎯 SENSI", "🌐 APPS", "🛠 TOOLS").forEachIndexed { i, name ->
            val t = Util.pill(c, name, Util.CARD) { showTab(i) }.apply { textSize = 11f; setPadding(dp(4), dp(9), dp(4), dp(9)); layoutParams = wlp() }
            tabBtns.add(t); tabs.addView(t)
        }
        val ct = FrameLayout(c)
        content = ct
        p.addView(head); p.addView(tabs)
        p.addView(ct, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.95).toInt(), (dm.heightPixels * 0.62).toInt(), type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(40)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(p, lp); panel = p
        showTab(0)
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        web?.destroy(); web = null; panel = null; content = null
        vRam = null; vTemp = null; vPing = null; vBat = null; vStatus = null
    }

    private fun showTab(i: Int) {
        tabBtns.forEachIndexed { k, t -> t.background = Util.round(this, if (k == i) Util.ORANGE else Util.CARD, 12) }
        val ct = content ?: return
        ct.removeAllViews()
        web?.destroy(); web = null
        vRam = null; vTemp = null; vPing = null; vBat = null; vStatus = null
        when (i) { 0 -> ct.addView(dashTab()); 1 -> ct.addView(sensiTab()); 2 -> ct.addView(appsTab()); else -> ct.addView(toolsTab()) }
        refreshStats()
    }

    private fun dashTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        fun card(name: String): TextView {
            val box = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
                background = Util.round(c, Util.CARD, 14); layoutParams = wlp() }
            val v = TextView(c).apply { setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; text = "--" }
            box.addView(v)
            box.addView(TextView(c).apply { text = name; setTextColor(Color.parseColor("#8FA3BF")); textSize = 10f; gravity = Gravity.CENTER })
            row.addView(box); return v
        }
        vRam = card("RAM"); vTemp = card("TEMP"); vPing = card("PING ms"); vBat = card("BATTERY")
        col.addView(row)
        vStatus = TextView(c).apply { textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4)) }
        col.addView(vStatus)
        col.addView(Util.pill(c, "🚀  GAME BOOST", Util.ORANGE) { doBoost(false) }.apply { textSize = 18f; layoutParams = mlp() })
        col.addView(Util.pill(c, "🎮  BOOST + PLAY FREE FIRE", Util.BLUE) { doBoost(true) }.apply { layoutParams = mlp() })
        col.addView(label("Tip: bubble ni nokki pattukunte quick boost avthundi."))
        return scroll(col)
    }

    private fun sensiTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("🎯 Free Fire Sensitivity (0-100). Preset tap chey, tarvata game lo ide numbers pettuko:"))
        val bars = ArrayList<SeekBar>(); val vals = ArrayList<TextView>()
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, arr) in presets) {
            pr.addView(Util.pill(c, name, Util.BLUE) { for (k in 0..5) bars[k].progress = arr[k] }.apply { layoutParams = wlp() })
        }
        col.addView(pr)
        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        for (k in 0..5) {
            val line = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), 0) }
            line.addView(TextView(c).apply { text = sensNames[k]; setTextColor(Color.WHITE); textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            val vt = TextView(c).apply { text = "${sens[k]}"; setTextColor(Util.CYAN); textSize = 14f; typeface = Typeface.DEFAULT_BOLD }
            vals.add(vt); line.addView(vt)
            val sb = SeekBar(c).apply {
                max = 100; progress = sens[k]
                progressTintList = ColorStateList.valueOf(Util.ORANGE); thumbTintList = ColorStateList.valueOf(Util.CYAN)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                        sens[k] = v; vals[k].text = "$v"; sp.edit().putInt("s$k", v).apply() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            bars.add(sb); col.addView(line); col.addView(sb)
        }
        col.addView(label("⚠ Ee app game lo sensitivity ni direct ga marchadu (Android lo adi sadhyam kaadu). Numbers choosi Free Fire > Settings > Sensitivity lo neeve set cheyali.\nTouch smooth kavalante: screen protector teeyi, chetulu dry ga pettuko."))
        col.addView(Util.pill(c, "🎮 Free Fire open", Util.ORANGE) {
            closePanel(); if (!Util.launchGame(this)) banner("❌ Free Fire dorakaledu", "Install check chey") }.apply { layoutParams = mlp() })
        return scroll(col)
    }

    private fun appsTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val w = WebView(c).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; webViewClient = WebViewClient()
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            loadUrl("https://m.youtube.com")
        }
        val desktop = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
        val bar = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(Util.pill(c, "YouTube", Color.parseColor("#C62828")) { w.settings.userAgentString = null; w.loadUrl("https://m.youtube.com") }.apply { layoutParams = wlp() })
        bar.addView(Util.pill(c, "Google", Util.BLUE) { w.settings.userAgentString = null; w.loadUrl("https://www.google.com") }.apply { layoutParams = wlp() })
        bar.addView(Util.pill(c, "WhatsApp", Color.parseColor("#2E7D32")) { w.settings.userAgentString = desktop; w.loadUrl("https://web.whatsapp.com") }.apply { layoutParams = wlp() })
        col.addView(bar); col.addView(w)
        web = w
        return col
    }

    private fun toolsTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("🎙 Voice changer (earphones tappakunda pettuko)", 12f, Color.WHITE))
        val vp = Util.pill(c, if (VoiceEngine.on) "🎙 VOICE: ON" else "🎙 VOICE: OFF", Util.CARD) {}
        vp.layoutParams = mlp()
        vp.setOnClickListener {
            if (!Util.hasMic(this)) { banner("🎙 Mic permission kavali", "Main app open chesi Allow chey") }
            else { val on = VoiceEngine.toggle(); vp.text = if (on) "🎙 VOICE: ON" else "🎙 VOICE: OFF" }
        }
        col.addView(vp)
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("Deep", "Normal", "High", "Chip"); val ps = listOf(0.75f, 1.0f, 1.3f, 1.6f)
        for (k in 0..3) pr.addView(Util.pill(c, names[k], Util.BLUE) { VoiceEngine.pitch = ps[k] }.apply { textSize = 11f; layoutParams = wlp() })
        col.addView(pr)
        col.addView(label("🔧 Quick tools", 12f, Color.WHITE))
        val r1 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(Util.pill(c, "🔕 DND ON", Util.CARD) { if (!Util.dnd(this, true)) askDnd() else banner("🔕 DND ON", "Notifications aagipoyayi") }.apply { layoutParams = wlp() })
        r1.addView(Util.pill(c, "🔔 DND OFF", Util.CARD) { if (!Util.dnd(this, false)) askDnd() else banner("🔔 DND OFF", "Notifications malli vastayi") }.apply { layoutParams = wlp() })
        col.addView(r1)
        val r2 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(Util.pill(c, "📶 PING TEST", Util.CARD) {
            Util.ping { r -> h.post { banner("📶 Ping", if (r < 0) "Internet ledu" else "$r ms " + (if (r < 60) "🟢 Super" else if (r < 120) "🟡 OK" else "🔴 High")) } } }.apply { layoutParams = wlp() })
        r2.addView(Util.pill(c, "🌐 PING FIX (DNS)", Util.CARD) {
            closePanel()
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            banner("🌐 Private DNS", "dns.google ani pettu") }.apply { layoutParams = wlp() })
        col.addView(r2)
        return scroll(col)
    }

    private fun askDnd() {
        banner("🔑 DND permission kavali", "Settings lo Prabhu Game Booster on chey")
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- live stats ----------
    private fun refreshStats() {
        val t = Util.temp(this); val ram = Util.ramPercent(this)
        vRam?.text = "$ram%"; vRam?.setTextColor(if (ram > 85) Util.RED else Color.WHITE)
        vTemp?.text = "%.0f°".format(t)
        vTemp?.setTextColor(if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        vPing?.text = if (ping < 0) "--" else "$ping"
        vPing?.setTextColor(if (ping < 0) Util.RED else if (ping < 60) Util.GREEN else if (ping < 120) Util.ORANGE else Util.RED)
        vBat?.text = "${Util.battery(this)}%"
        vStatus?.text = if (t >= 42) "🔥 Phone vedi undi! 5 min break teesko, case teesey" else if (t >= 38) "🟠 Konchem warm" else "🟢 Phone cool, game ki ready"
        bubble?.let { it.ram = ram; it.temp = t; it.invalidate() }
    }

    private fun tick() {
        if (!alive) return
        Util.ping { ping = it }
        refreshStats()
        h.postDelayed({ tick() }, 2500)
    }

    override fun onDestroy() {
        alive = false; closePanel()
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble = null; super.onDestroy()
    }
}
