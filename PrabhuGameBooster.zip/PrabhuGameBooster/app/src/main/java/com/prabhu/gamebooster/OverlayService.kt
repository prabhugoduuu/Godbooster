package com.prabhu.gamebooster

import android.app.*
import android.content.*
import android.content.res.ColorStateList
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.view.*
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var content: FrameLayout? = null
    private var appWin: LinearLayout? = null
    private var appLp: WindowManager.LayoutParams? = null
    private var appWeb: WebView? = null
    private var sizeIdx = 1
    private val sizes = listOf(0.70f to 0.38f, 0.90f to 0.52f, 0.97f to 0.72f)
    private var bannerView: View? = null
    private val tabBtns = ArrayList<TextView>()
    private val modeBtns = ArrayList<TextView>()
    private var gCpu: GaugeView? = null
    private var gGpu: GaugeView? = null
    private var gRam: GaugeView? = null
    private var gTemp: GaugeView? = null
    private var vStatus: TextView? = null
    private var modeDescV: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private var alive = true
    private var lastAuto = 0L
    private var lastHeat = 0L
    @Volatile private var ping = -1L
    private val sens = IntArray(6)
    private val sensNames = listOf("General", "Red Dot", "2x Scope", "4x Scope", "Sniper", "AWM")
    private val presets = linkedMapOf(
        "Normal" to intArrayOf(75, 70, 65, 60, 50, 45),
        "High" to intArrayOf(88, 84, 80, 75, 65, 60),
        "Pro" to intArrayOf(95, 92, 88, 84, 75, 70),
        "Max" to intArrayOf(100, 100, 98, 95, 88, 85))
    private val desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = Util.dp(this, v)
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun mlp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }
    private fun wlp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(5), dp(3), dp(5)) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("pgb", "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pgb") else Notification.Builder(this))
            .setContentTitle("Prabhu Game Booster is running").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        val d = presets["High"]!!
        for (k in 0..5) sens[k] = sp.getInt("s$k", d[k])
        addBubble(); applyAwake(); tick()
    }

    // ---------------- bubble ----------------
    private fun addBubble() {
        val b = BubbleView(this)
        val lp = WindowManager.LayoutParams(dp(58), dp(58), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 20; lp.y = 300
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var longDone = false
        val lpr = Runnable { if (!moved) { longDone = true; doBoost(false) } }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; longDone = false; h.postDelayed(lpr, 600); true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) { moved = true; h.removeCallbacks(lpr) }
                    lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(b, lp); true
                }
                MotionEvent.ACTION_UP -> { h.removeCallbacks(lpr); if (!moved && !longDone) togglePanel(); true }
                else -> false
            }
        }
        wm.addView(b, lp); bubble = b; bubbleLp = lp
    }

    private fun applyAwake() {
        val lp = bubbleLp ?: return; val b = bubble ?: return
        val keep = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        lp.flags = if (Modes.awake(Modes.get(this))) lp.flags or keep else lp.flags and keep.inv()
        try { wm.updateViewLayout(b, lp) } catch (e: Exception) {}
    }

    // ---------------- banner ----------------
    private fun banner(title: String, sub: String, color: Int = Util.GREEN) {
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        val ll = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(22), dp(14), dp(22), dp(14))
            background = Util.round(this@OverlayService, Color.parseColor("#F20B0F1A"), 18, color)
        }
        ll.addView(TextView(this).apply { text = title; setTextColor(color); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        ll.addView(TextView(this).apply { text = sub; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
        val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(60)
        ll.alpha = 0f; ll.scaleX = 0.7f; ll.scaleY = 0.7f
        wm.addView(ll, lp); bannerView = ll
        ll.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start()
        h.postDelayed({
            if (bannerView === ll) {
                ll.animate().alpha(0f).setDuration(300).withEndAction { try { wm.removeView(ll) } catch (e: Exception) {} }.start()
                bannerView = null
            }
        }, 2800)
    }

    private fun doBoost(play: Boolean) {
        banner("BOOSTING...", "Closing background apps")
        val mode = Modes.get(this)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            banner("GAME BOOSTED  [${Modes.names[mode]}]",
                (if (freed > 0) "$freed MB freed" else "RAM already clean") + "  |  $avail MB free\n%.0f°C".format(t) +
                    (if (dnd) "  |  DND ON" else ""))
            if (play) { closePanel(); if (!Util.launchGame(this)) banner("Free Fire not found", "Check that the game is installed", Util.ORANGE) }
            refreshStats()
        }
    }

    // ---------------- dashboard panel ----------------
    private fun small(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(12), dp(4), dp(12), dp(4)); setOnClickListener { f() } }

    private fun label(t: String, size: Float = 12f, color: Int = Color.parseColor("#8FA3BF")) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); setPadding(dp(4), dp(6), dp(4), dp(2)) }

    private fun scroll(v: View) = ScrollView(this).apply { addView(v) }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val c = this
        val p = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Util.round(c, Color.parseColor("#F40B0F1A"), 22, Util.CYAN)
        }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(c).apply {
            text = "PRABHU GAME BOOSTER"; setTextColor(Util.CYAN); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.06f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        head.addView(small("✕") { closePanel() }); head.addView(small("⏻") { stopSelf() })
        val tabs = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        tabBtns.clear()
        listOf("DASH", "APPS", "SENSI", "TOOLS").forEachIndexed { i, name ->
            val t = Util.pill(c, name, Util.CARD) { showTab(i) }.apply { textSize = 11f; setPadding(dp(4), dp(9), dp(4), dp(9)); layoutParams = wlp() }
            tabBtns.add(t); tabs.addView(t)
        }
        val ct = FrameLayout(c); content = ct
        p.addView(head); p.addView(tabs)
        p.addView(ct, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.95).toInt(), (dm.heightPixels * 0.62).toInt(), type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(40)
        wm.addView(p, lp); panel = p
        showTab(0)
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        panel = null; content = null
        gCpu = null; gGpu = null; gRam = null; gTemp = null; vStatus = null; modeDescV = null
    }

    private fun showTab(i: Int) {
        tabBtns.forEachIndexed { k, t -> t.background = Util.round(this, if (k == i) Util.ORANGE else Util.CARD, 12) }
        val ct = content ?: return
        ct.removeAllViews()
        gCpu = null; gGpu = null; gRam = null; gTemp = null; vStatus = null; modeDescV = null
        when (i) { 0 -> ct.addView(dashTab()); 1 -> ct.addView(appsTab()); 2 -> ct.addView(sensiTab()); else -> ct.addView(toolsTab()) }
        refreshStats()
    }

    private fun setMode(i: Int) {
        Modes.set(this, i); paintModes(); applyAwake(); lastAuto = 0L
        banner("MODE: ${Modes.names[i]}", Modes.desc[i].substringAfter(": "), Util.CYAN)
    }

    private fun paintModes() {
        val cur = Modes.get(this)
        modeBtns.forEachIndexed { k, b -> b.background = Util.round(this, if (k == cur) Util.ORANGE else Util.CARD, 12) }
        modeDescV?.text = Modes.desc[cur]
    }

    private fun dashTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        fun gauge(l: String) = GaugeView(c).apply {
            this.label = l; layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(2), dp(6), dp(2), 0) } }
        gCpu = gauge("CPU"); gGpu = gauge("GPU"); gRam = gauge("RAM"); gTemp = gauge("TEMP")
        col.addView(LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; addView(gCpu); addView(gGpu); addView(gRam); addView(gTemp) })
        vStatus = TextView(c).apply { textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(4)) }
        col.addView(vStatus)
        col.addView(label("PERFORMANCE MODE", 11f, Util.CYAN))
        val mr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        modeBtns.clear()
        Modes.names.forEachIndexed { i, n ->
            val b = Util.pill(c, n, Util.CARD) { setMode(i) }.apply { textSize = 10f; setPadding(dp(2), dp(9), dp(2), dp(9)); layoutParams = wlp() }
            modeBtns.add(b); mr.addView(b)
        }
        col.addView(mr)
        modeDescV = label("", 11f); col.addView(modeDescV)
        paintModes()
        col.addView(Util.pill(c, "BOOST NOW", Util.ORANGE) { doBoost(false) }.apply { textSize = 17f; layoutParams = mlp() })
        col.addView(Util.pill(c, "BOOST + PLAY FREE FIRE", Util.BLUE) { doBoost(true) }.apply { layoutParams = mlp() })
        col.addView(label("Tip: press and hold the bubble for a quick boost."))
        return scroll(col)
    }

    // ---------------- floating apps ----------------
    private fun tile(name: String, color: Int, url: String, desktop: Boolean) = TextView(this).apply {
        text = name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = Util.round(this@OverlayService, color, 16); setPadding(0, dp(28), 0, dp(28))
        layoutParams = wlp(); setOnClickListener { openApp(url, desktop) }
    }

    private fun appsTab(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("Floating apps open in their own small window. Drag the top bar to move, use the resize button, and the red X to close.", 11f))
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(tile("YouTube", Color.parseColor("#C62828"), "https://m.youtube.com", false))
            addView(tile("Google", Util.BLUE, "https://www.google.com", false)) })
        col.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
            addView(tile("WhatsApp", Color.parseColor("#2E7D32"), "https://web.whatsapp.com", true))
            addView(tile("Instagram", Color.parseColor("#AD1457"), "https://www.instagram.com", false)) })
        col.addView(label("Note: Google may block sign-in inside embedded browsers. Watching, searching and Instagram/WhatsApp Web work normally.", 10f))
        return scroll(col)
    }

    private fun openApp(url: String, desktop: Boolean) {
        closeApp(); closePanel()
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(1), dp(1), dp(1), dp(1))
            background = Util.round(c, Color.parseColor("#101018"), 14, Color.parseColor("#55FFFFFF")) }
        val bar = FrameLayout(c).apply { setBackgroundColor(Color.parseColor("#1A2236")) }
        bar.addView(View(c).apply { background = Util.round(c, Color.parseColor("#77FFFFFF"), 3); layoutParams = FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER) })
        bar.addView(TextView(c).apply {
            text = "⤢"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END).apply { rightMargin = dp(40) }
            setOnClickListener { sizeIdx = (sizeIdx + 1) % sizes.size; applySize() } })
        bar.addView(TextView(c).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER; setBackgroundColor(Color.parseColor("#D32F2F"))
            layoutParams = FrameLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
            setOnClickListener { closeApp() } })
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)))
        val w = WebView(c).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            if (desktop) { settings.userAgentString = desktopUA; settings.useWideViewPort = true; settings.loadWithOverviewMode = true }
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = WebViewClient(); webChromeClient = WebChromeClient()
            loadUrl(url)
        }
        root.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * sizes[sizeIdx].first).toInt(), (dm.heightPixels * sizes[sizeIdx].second).toInt(), type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = dp(12); lp.y = dp(90)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(root, lp); true }
                else -> false
            }
        }
        wm.addView(root, lp); appWin = root; appLp = lp; appWeb = w
    }

    private fun applySize() {
        val lp = appLp ?: return; val v = appWin ?: return
        val dm = resources.displayMetrics
        lp.width = (dm.widthPixels * sizes[sizeIdx].first).toInt(); lp.height = (dm.heightPixels * sizes[sizeIdx].second).toInt()
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    private fun closeApp() {
        appWin?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        appWeb?.destroy(); appWeb = null; appWin = null; appLp = null
    }

    // ---------------- sensitivity ----------------
    private fun sensiTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("FREE FIRE SENSITIVITY (0-100). Tap a preset, then enter the same numbers in the game.", 11f, Util.CYAN))
        val bars = ArrayList<SeekBar>(); val vals = ArrayList<TextView>()
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, arr) in presets) pr.addView(Util.pill(c, name, Util.BLUE) { for (k in 0..5) bars[k].progress = arr[k] }.apply { layoutParams = wlp() })
        col.addView(pr)
        val sp = getSharedPreferences("sensi", MODE_PRIVATE)
        for (k in 0..5) {
            val line = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), 0) }
            line.addView(TextView(c).apply { text = sensNames[k]; setTextColor(Color.WHITE); textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
            val vt = TextView(c).apply { text = "${sens[k]}"; setTextColor(Util.CYAN); textSize = 14f; typeface = Typeface.DEFAULT_BOLD }
            vals.add(vt); line.addView(vt)
            val sb = SeekBar(c).apply {
                max = 100; progress = sens[k]
                progressTintList = ColorStateList.valueOf(Util.ORANGE); thumbTintList = ColorStateList.valueOf(Util.CYAN)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { sens[k] = v; vals[k].text = "$v"; sp.edit().putInt("s$k", v).apply() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            bars.add(sb); col.addView(line); col.addView(sb)
        }
        col.addView(label("This app cannot change in-game sensitivity (Android does not allow it). Use these values as a starting point in Free Fire > Settings > Sensitivity and adjust to your hand.", 10f))
        col.addView(Util.pill(c, "OPEN FREE FIRE", Util.ORANGE) {
            closePanel(); if (!Util.launchGame(this)) banner("Free Fire not found", "Check that the game is installed", Util.ORANGE) }.apply { layoutParams = mlp() })
        return scroll(col)
    }

    // ---------------- tools ----------------
    private fun toolsTab(): View {
        val c = this
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("VOICE CHANGER (use earphones to avoid echo)", 11f, Util.CYAN))
        val vp = Util.pill(c, if (VoiceEngine.on) "VOICE: ON" else "VOICE: OFF", Util.CARD) {}
        vp.layoutParams = mlp()
        vp.setOnClickListener {
            if (!Util.hasMic(this)) banner("Microphone permission needed", "Open the main app and tap Allow", Util.ORANGE)
            else { val on = VoiceEngine.toggle(); vp.text = if (on) "VOICE: ON" else "VOICE: OFF" }
        }
        col.addView(vp)
        val pr = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val names = listOf("Deep", "Normal", "High", "Chipmunk"); val ps = listOf(0.75f, 1.0f, 1.3f, 1.6f)
        for (k in 0..3) pr.addView(Util.pill(c, names[k], Util.BLUE) { VoiceEngine.pitch = ps[k] }.apply { textSize = 10f; layoutParams = wlp() })
        col.addView(pr)
        col.addView(label("QUICK TOOLS", 11f, Util.CYAN))
        val r1 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(Util.pill(c, "DND ON", Util.CARD) { if (!Util.dnd(this, true)) askDnd() else banner("DND ON", "Notifications silenced") }.apply { layoutParams = wlp() })
        r1.addView(Util.pill(c, "DND OFF", Util.CARD) { if (!Util.dnd(this, false)) askDnd() else banner("DND OFF", "Notifications restored") }.apply { layoutParams = wlp() })
        col.addView(r1)
        val r2 = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(Util.pill(c, "PING TEST", Util.CARD) {
            Util.ping { r -> h.post { banner("PING", if (r < 0) "No internet" else "$r ms  " + (if (r < 60) "Excellent" else if (r < 120) "Good" else "High")) } } }.apply { layoutParams = wlp() })
        r2.addView(Util.pill(c, "FIX PING (DNS)", Util.CARD) {
            closePanel()
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            banner("PRIVATE DNS", "Set it to dns.google", Util.CYAN) }.apply { layoutParams = wlp() })
        col.addView(r2)
        return scroll(col)
    }

    private fun askDnd() {
        banner("DND access needed", "Enable it for Prabhu Game Booster", Util.ORANGE)
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------------- live stats ----------------
    private fun refreshStats() {
        val t = Util.temp(this); val ram = Util.ramPercent(this)
        if (gCpu != null) {
            val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad()
            gCpu?.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
            gGpu?.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
            gRam?.set(ram, "$ram%", Util.loadColor(ram))
            gTemp?.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°".format(t), if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
            vStatus?.text = "Ping " + (if (ping < 0) "--" else "$ping ms") + "   Battery ${Util.battery(this)}%   Thermal ${SysInfo.thermal(this)}" +
                (if (t >= 42) "\nPhone is hot. Take a short break." else "")
        }
        bubble?.let { it.ram = ram; it.temp = t; it.invalidate() }
    }

    private fun tick() {
        if (!alive) return
        Util.ping { ping = it }
        refreshStats()
        val mode = Modes.get(this); val now = System.currentTimeMillis(); val sec = Modes.autoSec(mode)
        if (sec > 0 && now - lastAuto > sec * 1000L) { lastAuto = now; Util.clean(this) }
        if (mode == 3 && Util.temp(this) >= 43f && now - lastHeat > 120000L) {
            lastHeat = now; banner("HIGH TEMPERATURE", "Take a short break and remove the phone case", Util.RED)
        }
        h.postDelayed({ tick() }, 2000)
    }

    override fun onDestroy() {
        alive = false; closePanel(); closeApp()
        bannerView?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble = null; super.onDestroy()
    }
}
