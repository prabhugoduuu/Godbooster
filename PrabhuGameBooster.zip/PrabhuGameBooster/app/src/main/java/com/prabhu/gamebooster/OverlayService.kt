package com.prabhu.gamebooster

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var web: WebView? = null
    private var stats: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    @Volatile private var ping = -1L
    private var alive = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("pgb", "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "pgb") else Notification.Builder(this))
            .setContentTitle("Prabhu Game Booster running").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n)
        addBubble(); tick()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun type() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble() {
        val b = TextView(this).apply {
            text = "P"; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#CCFF5722")) }
        }
        val lp = WindowManager.LayoutParams(dp(54), dp(54), type(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 20; lp.y = 300
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(b, lp); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        wm.addView(b, lp); bubble = b
    }

    private fun tb(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 10f; setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#F0101018")) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val w = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            loadUrl("https://m.youtube.com")
        }
        val desktop = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
        bar.addView(tb("YouTube") { w.settings.userAgentString = null; w.loadUrl("https://m.youtube.com") })
        bar.addView(tb("Google") { w.settings.userAgentString = null; w.loadUrl("https://www.google.com") })
        bar.addView(tb("WhatsApp") { w.settings.userAgentString = desktop; w.loadUrl("https://web.whatsapp.com") })
        bar.addView(tb("✕") { closePanel() })
        bar.addView(tb("⏻") { stopSelf() })
        val s = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; setPadding(16, 6, 16, 6) }
        p.addView(bar); p.addView(s); p.addView(w)
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.55).toInt(), type(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.y = dp(50)
        wm.addView(p, lp); panel = p; web = w; stats = s
    }

    private fun closePanel() {
        panel?.let { wm.removeView(it) }; web?.destroy(); panel = null; web = null; stats = null
    }

    private fun tick() {
        if (!alive) return
        val t = Util.temp(this)
        Util.ping { ping = it }
        bubble?.text = "%.0f°".format(t)
        val hot = t >= 42
        stats?.text = "🌡 $t°C  📶 " + (if (ping < 0) "--" else "$ping ms") + if (hot) "  🔥 Break teesko!" else ""
        stats?.setTextColor(if (hot) Color.RED else Color.WHITE)
        h.postDelayed({ tick() }, 3000)
    }

    override fun onDestroy() {
        alive = false; closePanel(); bubble?.let { wm.removeView(it) }; bubble = null; super.onDestroy()
    }
}
