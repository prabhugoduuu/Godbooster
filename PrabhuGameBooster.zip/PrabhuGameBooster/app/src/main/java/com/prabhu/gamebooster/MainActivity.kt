package com.prabhu.gamebooster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var vRam: TextView
    private lateinit var vTemp: TextView
    private lateinit var vPing: TextView
    private lateinit var vBat: TextView
    private lateinit var result: TextView
    private lateinit var pitchBtn: TextView
    private lateinit var voiceBtn: TextView
    private val pitches = floatArrayOf(0.75f, 1.0f, 1.3f, 1.6f)
    private val pitchNames = arrayOf("Deep", "Normal", "High", "Chipmunk")
    private var pi = 1
    @Volatile private var ping = -1L
    private var alive = true

    private fun dp(v: Int) = Util.dp(this, v)
    private fun lpm() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(40), dp(14), dp(24)); setBackgroundColor(Util.BG) }
        root.addView(TextView(this).apply {
            text = "⚡ PRABHU"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Util.ORANGE); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "G A M E   B O O S T E R"; textSize = 13f; setTextColor(Util.CYAN); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(14)) })

        fun card(label: String): TextView {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14))
                background = Util.round(this@MainActivity, Util.CARD, 16, Color.parseColor("#2200E5FF")); layoutParams = lpm() }
            val v = TextView(this).apply { setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; text = "--" }
            box.addView(v)
            box.addView(TextView(this).apply { text = label; setTextColor(Color.parseColor("#8FA3BF")); textSize = 11f; gravity = Gravity.CENTER })
            (root.getChildAt(root.childCount - 1) as LinearLayout).addView(box)
            return v
        }
        root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL })
        vRam = card("RAM USED"); vTemp = card("TEMP")
        root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL })
        vPing = card("PING ms"); vBat = card("BATTERY")

        val boostBtn = TextView(this).apply {
            text = "🚀\nBOOST"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Util.ORANGE, Color.parseColor("#FF9100"))).apply { shape = GradientDrawable.OVAL }
            layoutParams = LinearLayout.LayoutParams(dp(170), dp(170)).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, dp(22), 0, dp(12)) }
        }
        boostBtn.setOnClickListener {
            boostBtn.animate().scaleX(0.88f).scaleY(0.88f).setDuration(120).withEndAction {
                boostBtn.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
            doBoost(false)
        }
        root.addView(boostBtn)

        result = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(dp(16), dp(16), dp(16), dp(16)); background = Util.round(this@MainActivity, Color.parseColor("#102A1E"), 16, Util.GREEN)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), dp(8), dp(4), dp(12)) }
        }
        root.addView(result)

        fun pair(a: View, c: View) {
            a.layoutParams = lpm(); c.layoutParams = lpm()
            root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(a); addView(c) })
        }
        pair(Util.pill(this, "▶ OVERLAY START", Util.BLUE) { startOverlay() },
             Util.pill(this, "■ OVERLAY STOP", Util.CARD) { stopService(Intent(this, OverlayService::class.java)) })
        pair(Util.pill(this, "🎮 BOOST + PLAY FREE FIRE", Util.ORANGE) { doBoost(true) },
             Util.pill(this, "🌐 PING FIX (DNS)", Util.CARD) {
                 result.visibility = View.VISIBLE
                 result.text = "Private DNS lo ivvu:\ndns.google\nleda 1dot1dot1dot1.cloudflare-dns.com"
                 startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) })
        voiceBtn = Util.pill(this, "🎙 VOICE: OFF", Util.CARD) {
            if (!Util.hasMic(this)) { toast("Mic permission ivvu") } else {
                val on = VoiceEngine.toggle(); voiceBtn.text = if (on) "🎙 VOICE: ON" else "🎙 VOICE: OFF"
                if (on) toast("Earphones pettuko!") } }
        pitchBtn = Util.pill(this, "🎚 Voice: Normal", Util.CARD) {
            pi = (pi + 1) % pitches.size; VoiceEngine.pitch = pitches[pi]; pitchBtn.text = "🎚 Voice: ${pitchNames[pi]}" }
        pair(voiceBtn, pitchBtn)
        pair(Util.pill(this, "🔑 OVERLAY PERMISSION", Util.CARD) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) },
             Util.pill(this, "🔕 DND PERMISSION", Util.CARD) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
        root.addView(TextView(this).apply {
            text = "Overlay start chesaka floating ⚡ bubble tap chey: DASH, SENSI, APPS, TOOLS.\nBubble ni nokki pattukunte (long press) quick BOOST."
            textSize = 12f; setTextColor(Color.parseColor("#8FA3BF")); gravity = Gravity.CENTER; setPadding(0, dp(14), 0, 0) })

        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Util.BG) })

        if (Build.VERSION.SDK_INT >= 23) {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
            requestPermissions(perms.toTypedArray(), 1)
        }
        tick()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun tick() {
        if (!alive) return
        val t = Util.temp(this); val ram = Util.ramPercent(this)
        vRam.text = "$ram%"; vRam.setTextColor(if (ram > 85) Util.RED else Color.WHITE)
        vTemp.text = "%.0f°C".format(t)
        vTemp.setTextColor(if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        vBat.text = "${Util.battery(this)}%"
        Util.ping { ping = it; runOnUiThread { vPing.text = if (it < 0) "--" else "$it"
            vPing.setTextColor(if (it < 0) Util.RED else if (it < 60) Util.GREEN else if (it < 120) Util.ORANGE else Util.RED) } }
        h.postDelayed({ tick() }, 2500)
    }

    private fun doBoost(play: Boolean) {
        result.visibility = View.VISIBLE; result.text = "⚡ Boosting..."
        Util.boost(this) { freed, avail ->
            val dnd = Util.dnd(this, true)
            val t = Util.temp(this)
            result.text = "✅ GAME BOOSTED!\n\n" +
                (if (freed > 0) "🧹 $freed MB RAM freed" else "🧹 RAM already clean ✨") +
                "\n💾 Free RAM: $avail MB\n🌡 %.0f°C".format(t) + (if (dnd) "\n🔕 DND ON" else "") +
                (if (t >= 42) "\n🔥 Phone vedi! Konchem break teesko" else "")
            result.alpha = 0f; result.scaleX = 0.85f; result.scaleY = 0.85f
            result.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
            if (play && !Util.launchGame(this)) result.append("\n❌ Free Fire dorakaledu")
        }
    }

    private fun startOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { toast("Mundu Overlay permission ivvu"); return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        toast("Overlay start ayyindi ⚡")
    }

    override fun onDestroy() { alive = false; super.onDestroy() }
}
