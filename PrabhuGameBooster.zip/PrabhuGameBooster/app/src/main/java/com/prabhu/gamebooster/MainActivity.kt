package com.prabhu.gamebooster

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var gCpu: GaugeView
    private lateinit var gGpu: GaugeView
    private lateinit var gRam: GaugeView
    private lateinit var gTemp: GaugeView
    private lateinit var info: TextView
    private lateinit var result: TextView
    private lateinit var modeDesc: TextView
    private lateinit var voiceBtn: TextView
    private lateinit var pitchBtn: TextView
    private lateinit var pOverlay: TextView
    private lateinit var pDnd: TextView
    private lateinit var pMic: TextView
    private val modeBtns = ArrayList<TextView>()
    private val pitches = floatArrayOf(0.75f, 1.0f, 1.3f, 1.6f)
    private val pitchNames = arrayOf("Deep", "Normal", "High", "Chipmunk")
    private var pi = 1
    private var gpuName = "Detecting..."
    @Volatile private var ping = -1L
    private var alive = true

    private fun dp(v: Int) = Util.dp(this, v)
    private fun wl() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) }
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(2), dp(8), dp(2), dp(4)) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(36), dp(14), dp(24)); setBackgroundColor(Util.BG) }
        root.addView(TextView(this).apply { text = "PRABHU GAME BOOSTER"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); letterSpacing = 0.08f })
        root.addView(TextView(this).apply { text = "PERFORMANCE SUITE  |  v3.0"; textSize = 11f; setTextColor(Util.CYAN); setPadding(0, dp(2), 0, dp(14)) })

        fun gauge(l: String) = GaugeView(this).apply {
            this.label = l
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) } }
        gCpu = gauge("CPU"); gGpu = gauge("GPU"); gRam = gauge("RAM"); gTemp = gauge("TEMP")
        root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(gCpu); addView(gGpu); addView(gRam); addView(gTemp) })

        info = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11.5f; setTextColor(Color.parseColor("#C5D1E3")); setLineSpacing(0f, 1.25f)
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = Util.round(this@MainActivity, Util.CARD, 14); layoutParams = full() }
        root.addView(info)

        fun section(t: String) = TextView(this).apply { text = t; textSize = 11f; setTextColor(Util.CYAN); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(4), dp(14), 0, dp(2)); letterSpacing = 0.1f }
        root.addView(section("PERFORMANCE MODE"))
        val mr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Modes.names.forEachIndexed { i, n ->
            val bt = Util.pill(this, n, Util.CARD) { Modes.set(this, i); paintModes() }.apply { textSize = 11f; setPadding(dp(2), dp(11), dp(2), dp(11)); layoutParams = wl() }
            modeBtns.add(bt); mr.addView(bt)
        }
        root.addView(mr)
        modeDesc = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#8FA3BF")); setPadding(dp(4), dp(2), dp(4), dp(4)) }
        root.addView(modeDesc)
        paintModes()

        val boostBtn = TextView(this).apply {
            text = "BOOST NOW"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            letterSpacing = 0.1f; setPadding(0, dp(20), 0, dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Util.ORANGE, Color.parseColor("#FF9100"))).apply { cornerRadius = dp(16).toFloat() }
            layoutParams = full() }
        boostBtn.setOnClickListener {
            boostBtn.animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).withEndAction { boostBtn.animate().scaleX(1f).scaleY(1f).setDuration(100).start() }.start()
            doBoost(false)
        }
        root.addView(boostBtn)
        result = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); visibility = View.GONE; setLineSpacing(0f, 1.2f)
            setPadding(dp(16), dp(14), dp(16), dp(14)); background = Util.round(this@MainActivity, Color.parseColor("#102A1E"), 14, Util.GREEN); layoutParams = full() }
        root.addView(result)

        fun pair(a: View, c: View) {
            a.layoutParams = wl(); c.layoutParams = wl()
            root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(a); addView(c) })
        }
        root.addView(section("CONTROLS"))
        pair(Util.pill(this, "START OVERLAY", Util.BLUE) { startOverlay() },
             Util.pill(this, "STOP OVERLAY", Util.CARD) { stopService(Intent(this, OverlayService::class.java)) })
        pair(Util.pill(this, "BOOST + PLAY FREE FIRE", Util.ORANGE) { doBoost(true) },
             Util.pill(this, "FIX PING (DNS)", Util.CARD) {
                 result.visibility = View.VISIBLE
                 result.text = "Set Private DNS to:\ndns.google\nor 1dot1dot1dot1.cloudflare-dns.com"
                 startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) })
        voiceBtn = Util.pill(this, "VOICE CHANGER: OFF", Util.CARD) {
            if (!Util.hasMic(this)) toast("Grant microphone permission first") else {
                val on = VoiceEngine.toggle(); voiceBtn.text = if (on) "VOICE CHANGER: ON" else "VOICE CHANGER: OFF"
                if (on) toast("Use earphones to avoid echo") } }
        pitchBtn = Util.pill(this, "VOICE: Normal", Util.CARD) {
            pi = (pi + 1) % pitches.size; VoiceEngine.pitch = pitches[pi]; pitchBtn.text = "VOICE: ${pitchNames[pi]}" }
        pair(voiceBtn, pitchBtn)

        root.addView(section("SETUP"))
        pOverlay = Util.pill(this, "", Util.CARD) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }.apply { textSize = 11f }
        pDnd = Util.pill(this, "", Util.CARD) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }.apply { textSize = 11f }
        pMic = Util.pill(this, "", Util.CARD) { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }.apply { textSize = 11f }
        pOverlay.layoutParams = wl(); pDnd.layoutParams = wl(); pMic.layoutParams = wl()
        root.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(pOverlay); addView(pDnd); addView(pMic) })

        root.addView(TextView(this).apply {
            text = "Modes control RAM cleaning, Do Not Disturb, screen-awake and auto-clean. Changing real CPU/GPU clock speeds needs root, so this app monitors CPU/GPU but does not overclock. Some phones block CPU/GPU load readings; those show \"--\"."
            textSize = 11f; setTextColor(Color.parseColor("#8FA3BF")); setPadding(dp(4), dp(14), dp(4), 0) })

        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Util.BG) })

        if (Build.VERSION.SDK_INT >= 23) {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
            requestPermissions(perms.toTypedArray(), 1)
        }
        Thread { val n = SysInfo.gpuName(); h.post { gpuName = n } }.start()
        tick()
    }

    override fun onResume() { super.onResume(); refreshPerms() }

    private fun refreshPerms() {
        val ov = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val dn = Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted
        fun paint(v: TextView, n: String, ok: Boolean) {
            v.text = "$n: " + (if (ok) "ON" else "ENABLE")
            v.background = Util.round(this, if (ok) Color.parseColor("#1B5E20") else Color.parseColor("#7F1D1D"), 12) }
        paint(pOverlay, "Overlay", ov); paint(pDnd, "DND access", dn); paint(pMic, "Mic", Util.hasMic(this))
    }

    private fun paintModes() {
        val cur = Modes.get(this)
        modeBtns.forEachIndexed { k, b -> b.background = Util.round(this, if (k == cur) Util.ORANGE else Util.CARD, 12) }
        modeDesc.text = Modes.desc[cur]
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun tick() {
        if (!alive) return
        val cpu = SysInfo.cpuLoad(); val gpu = SysInfo.gpuLoad(); val ram = Util.ramPercent(this); val t = Util.temp(this)
        gCpu.set(cpu, if (cpu < 0) "--" else "$cpu%", Util.loadColor(cpu))
        gGpu.set(gpu, if (gpu < 0) "--" else "$gpu%", Util.loadColor(gpu))
        gRam.set(ram, "$ram%", Util.loadColor(ram))
        gTemp.set(((t - 25f) / 25f * 100).toInt().coerceIn(0, 100), "%.0f°".format(t), if (t >= 42) Util.RED else if (t >= 38) Util.ORANGE else Util.GREEN)
        val f = SysInfo.cpuFreq()
        info.text = "DEVICE   ${Build.MANUFACTURER} ${Build.MODEL}  |  Android ${Build.VERSION.RELEASE}\n" +
            "CPU      ${SysInfo.cpuName()}  |  ${SysInfo.cores} cores" + (if (f != null) "  |  ${f[0]}/${f[1]} MHz" else "") + "\n" +
            "GPU      $gpuName\n" +
            "MEMORY   ${Util.totalRam(this)}  |  Battery ${Util.battery(this)}%\n" +
            "STATUS   Thermal ${SysInfo.thermal(this)}  |  Ping " + (if (ping < 0) "--" else "$ping ms")
        Util.ping { ping = it }
        h.postDelayed({ tick() }, 2000)
    }

    private fun doBoost(play: Boolean) {
        result.visibility = View.VISIBLE; result.text = "Boosting..."
        val mode = Modes.get(this)
        Util.boost(this) { freed, avail ->
            val dnd = Modes.dnd(mode) && Util.dnd(this, true)
            val t = Util.temp(this)
            result.text = "GAME BOOSTED  [${Modes.names[mode]}]\n\n" +
                (if (freed > 0) "RAM freed: $freed MB" else "RAM already clean") +
                "\nFree RAM: $avail MB\nTemperature: %.0f°C".format(t) + (if (dnd) "\nDo Not Disturb: ON" else "") +
                (if (t >= 42) "\nPhone is hot. Take a short break." else "")
            result.alpha = 0f; result.scaleX = 0.9f; result.scaleY = 0.9f
            result.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start()
            if (play && !Util.launchGame(this)) result.append("\nFree Fire not found on this phone.")
        }
    }

    private fun startOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { toast("Enable the Overlay permission first"); return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        toast("Overlay started")
    }

    override fun onDestroy() { alive = false; super.onDestroy() }
}
