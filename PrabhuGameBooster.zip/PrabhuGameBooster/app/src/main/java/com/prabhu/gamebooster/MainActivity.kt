package com.prabhu.gamebooster

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView
    @Volatile private var voiceOn = false
    @Volatile private var pitch = 1.0f
    private val ff = listOf("com.dts.freefireth", "com.dts.freefiremax", "com.garena.game.fffi")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 70, 40, 40)
            setBackgroundColor(Color.parseColor("#0D0D14"))
        }
        root.addView(TextView(this).apply {
            text = "⚡ PRABHU GAME BOOSTER"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#FF5722")); gravity = Gravity.CENTER; setPadding(0, 0, 0, 30)
        })
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, 10, 0, 20); text = "Ready" }
        root.addView(info)
        btn(root, "1. Overlay permission ivvu") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn(root, "2. DND permission ivvu (optional)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        btn(root, "▶ Overlay START (YouTube/Google/WhatsApp)") { startOverlay() }
        btn(root, "■ Overlay STOP") { stopService(Intent(this, OverlayService::class.java)) }
        btn(root, "🚀 BOOST + Free Fire open") { boost(true) }
        btn(root, "❄ System Cooler (temp + RAM clean)") { boost(false) }
        btn(root, "📶 Ping check") { checkPing() }
        btn(root, "🌐 Ping control (Private DNS settings)") {
            info.text = "Settings > Private DNS > 'Private DNS provider hostname' lo ivvu:\n dns.google  leda  1dot1dot1dot1.cloudflare-dns.com\nWiFi weak aithe router daggara undu, background downloads aapu."
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
        root.addView(TextView(this).apply { text = "🎙 Voice changer (earphones vadu!)"; setTextColor(Color.WHITE); setPadding(0, 30, 0, 0) })
        root.addView(SeekBar(this).apply {
            max = 100; progress = 33
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { pitch = 0.7f + p / 100f * 0.9f / 1f; info.text = "Pitch: %.2f".format(pitch) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        btn(root, "🎙 Voice ON / OFF") { toggleVoice() }
        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#0D0D14")) })
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun btn(p: LinearLayout, t: String, f: () -> Unit) {
        p.addView(Button(this).apply { text = t; setOnClickListener { f() } })
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) { info.text = "Mundu Overlay permission ivvu"; return }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        info.text = "Overlay start ayyindi. Bubble tap chey."
    }

    private fun boost(launch: Boolean) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi); val before = mi.availMem
        packageManager.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != packageName }
            .forEach { am.killBackgroundProcesses(it.packageName) }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 23 && launch && nm.isNotificationPolicyAccessGranted)
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
        Handler(Looper.getMainLooper()).postDelayed({
            am.getMemoryInfo(mi)
            val freed = (mi.availMem - before) / 1048576
            val t = Util.temp(this)
            info.text = "RAM freed: ~${freed} MB\nFree RAM: ${mi.availMem / 1048576} MB\nTemp: $t°C" +
                if (t >= 42) "\n🔥 Phone vedi! Charger teeyi, case teesey, 5 min break teesko." else "\n✅ Temp OK"
            if (launch) {
                val li = ff.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
                if (li != null) startActivity(li) else info.append("\nFree Fire dorakaledu (install check chey)")
            }
        }, 800)
    }

    private fun checkPing() {
        info.text = "Checking..."
        Util.ping { r -> runOnUiThread {
            info.text = if (r < 0) "❌ Internet ledu" else "Ping: $r ms " +
                when { r < 60 -> "🟢 Super"; r < 120 -> "🟡 OK"; else -> "🔴 High - WiFi/DNS maaru" }
        } }
    }

    private fun toggleVoice() {
        if (voiceOn) { voiceOn = false; info.text = "Voice OFF"; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            info.text = "Mic permission ivvu"; return
        }
        voiceOn = true; info.text = "Voice ON (earphones pettuko)"
        Thread {
            val sr = 44100
            val ci = AudioFormat.CHANNEL_IN_MONO; val co = AudioFormat.CHANNEL_OUT_MONO; val enc = AudioFormat.ENCODING_PCM_16BIT
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, ci, enc, AudioRecord.getMinBufferSize(sr, ci, enc) * 2)
            val trk = AudioTrack(AudioManager.STREAM_MUSIC, sr, co, enc, AudioTrack.getMinBufferSize(sr, co, enc) * 2, AudioTrack.MODE_STREAM)
            rec.startRecording(); trk.play()
            val inp = ShortArray(1024)
            while (voiceOn) {
                val n = rec.read(inp, 0, inp.size); if (n <= 0) continue
                val f = pitch; val m = (n / f).toInt(); val out = ShortArray(m)
                for (i in 0 until m) {
                    val p = i * f; val a = p.toInt().coerceAtMost(n - 1); val c = (a + 1).coerceAtMost(n - 1); val fr = p - a
                    out[i] = (inp[a] * (1 - fr) + inp[c] * fr).toInt().toShort()
                }
                trk.write(out, 0, m)
            }
            rec.stop(); rec.release(); trk.stop(); trk.release()
        }.start()
    }

    override fun onDestroy() { voiceOn = false; super.onDestroy() }
}
