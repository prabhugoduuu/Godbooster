package com.prabhu.gamebooster

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.os.*
import android.view.Gravity
import android.widget.TextView
import java.net.InetSocketAddress
import java.net.Socket

object Util {
    val CYAN = Color.parseColor("#00E5FF")
    val ORANGE = Color.parseColor("#FF5722")
    val GREEN = Color.parseColor("#00E676")
    val RED = Color.parseColor("#FF1744")
    val BLUE = Color.parseColor("#1E88E5")
    val BG = Color.parseColor("#0B0F1A")
    val CARD = Color.parseColor("#1A2236")
    val GAMES = listOf("com.dts.freefireth", "com.dts.freefiremax", "com.garena.game.fffi")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, color: Int, r: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(c, r).toFloat()
            if (stroke != 0) setStroke(dp(c, 1), stroke)
        }

    fun pill(c: Context, t: String, color: Int, onClick: () -> Unit): TextView = TextView(c).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(c, 10), dp(c, 12), dp(c, 10), dp(c, 12))
        background = round(c, color, 14)
        setOnClickListener { onClick() }
    }

    fun temp(c: Context): Float {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra("temperature", 0) ?: 0) / 10f
    }

    fun battery(c: Context): Int {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", 0) ?: 0
        val s = i?.getIntExtra("scale", 100) ?: 100
        return if (s > 0) l * 100 / s else 0
    }

    fun ramPercent(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        return (100 - mi.availMem * 100 / mi.totalMem).toInt()
    }

    fun ping(cb: (Long) -> Unit) {
        Thread {
            val t = System.currentTimeMillis()
            val r = try {
                Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                System.currentTimeMillis() - t
            } catch (e: Exception) { -1L }
            cb(r)
        }.start()
    }

    // cb runs on main thread: (freedMB, freeRamMB)
    fun boost(c: Context, cb: (Long, Long) -> Unit) {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        val before = mi.availMem
        c.packageManager.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != c.packageName }
            .forEach { am.killBackgroundProcesses(it.packageName) }
        Handler(Looper.getMainLooper()).postDelayed({
            val m2 = ActivityManager.MemoryInfo(); am.getMemoryInfo(m2)
            cb(maxOf(0L, (m2.availMem - before) / 1048576), m2.availMem / 1048576)
        }, 900)
    }

    fun dnd(c: Context, on: Boolean): Boolean {
        if (Build.VERSION.SDK_INT < 23) return false
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return true
    }

    fun launchGame(c: Context): Boolean {
        val li = GAMES.firstNotNullOfOrNull { c.packageManager.getLaunchIntentForPackage(it) } ?: return false
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(li); return true
    }

    fun hasMic(c: Context) =
        c.packageManager.checkPermission("android.permission.RECORD_AUDIO", c.packageName) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
}

object VoiceEngine {
    @Volatile var on = false
    @Volatile var pitch = 1.0f

    fun toggle(): Boolean {
        if (on) { on = false; return false }
        on = true
        Thread {
            try {
                val sr = 44100
                val ci = AudioFormat.CHANNEL_IN_MONO; val co = AudioFormat.CHANNEL_OUT_MONO
                val enc = AudioFormat.ENCODING_PCM_16BIT
                val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, ci, enc, AudioRecord.getMinBufferSize(sr, ci, enc) * 2)
                val trk = AudioTrack(AudioManager.STREAM_MUSIC, sr, co, enc, AudioTrack.getMinBufferSize(sr, co, enc) * 2, AudioTrack.MODE_STREAM)
                try {
                    rec.startRecording(); trk.play()
                    val inp = ShortArray(1024)
                    while (on) {
                        val n = rec.read(inp, 0, inp.size); if (n <= 0) continue
                        val f = pitch; val m = (n / f).toInt(); val out = ShortArray(m)
                        for (i in 0 until m) {
                            val p = i * f
                            val a = p.toInt().coerceAtMost(n - 1); val b = (a + 1).coerceAtMost(n - 1); val fr = p - a
                            out[i] = (inp[a] * (1 - fr) + inp[b] * fr).toInt().toShort()
                        }
                        trk.write(out, 0, m)
                    }
                } finally {
                    try { rec.stop() } catch (e: Exception) {}
                    rec.release()
                    try { trk.stop() } catch (e: Exception) {}
                    trk.release()
                }
            } catch (e: Exception) { on = false }
        }.start()
        return true
    }
}
