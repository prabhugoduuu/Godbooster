package com.prabhu.gamebooster

import android.content.*
import java.net.InetSocketAddress
import java.net.Socket

object Util {
    fun temp(c: Context): Float {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra("temperature", 0) ?: 0) / 10f
    }
    fun ping(cb: (Long) -> Unit) {
        Thread {
            val t = System.currentTimeMillis()
            val r = try {
                Socket().use { it.connect(InetSocketAddress("8.8.8.8", 53), 1500) }
                System.currentTimeMillis() - t
            } catch (e: Exception) { -1L }
            cb(r)
        }.start()
    }
}
